const express = require("express")
const port = process.env.PORT||2000
const app = express()
app.get("/welcome",(req,res)=>{
    res.send("hello")
})
app.listen(port,()=>{
    console.log(`app is running on port of ${port}`)
})